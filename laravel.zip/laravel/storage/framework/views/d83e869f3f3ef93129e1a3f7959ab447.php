<?php $__env->startSection('title', 'Find Us'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="py-12 sm:py-16 lg:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="max-w-3xl">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-caramel/25 text-cocoa text-xs font-bold tracking-wide mb-4">
                <span>📍 Official Partner Locations</span>
            </div>
            <h1 class="font-heading text-4xl sm:text-6xl text-cocoa tracking-tight leading-tight">
                Catch Us Around.
            </h1>
            <p class="text-cocoa/85 text-base sm:text-lg mt-4 leading-relaxed font-normal">
                We've made our way into the places you love. Explore our selected locations and find your next bite along the way.
            </p>
        </div>

        <?php
            $defaultLocations = [
                (object)[
                    'name' => 'Verde Padel Club',
                    'type' => 'Padel Court',
                    'address' => 'Jl. Kemang Raya No. 12, Bangka, Mampang Prapatan, Jakarta Selatan',
                    'google_maps_link' => 'https://maps.google.com/?q=Verde+Padel+Club',
                ],
                (object)[
                    'name' => 'Powerhouse Fitness & Gym',
                    'type' => 'Gym & Fitness',
                    'address' => 'Jl. Senopati No. 45, Selong, Kebayoran Baru, Jakarta Selatan',
                    'google_maps_link' => 'https://maps.google.com/?q=Powerhouse+Gym',
                ],
                (object)[
                    'name' => 'The Movement Studio',
                    'type' => 'Pilates & Wellness',
                    'address' => 'Jl. Dharmawangsa VI No. 8, Pulo, Kebayoran Baru, Jakarta Selatan',
                    'google_maps_link' => 'https://maps.google.com/?q=The+Movement+Studio',
                ],
                (object)[
                    'name' => 'Slam Padel Arena',
                    'type' => 'Padel Court',
                    'address' => 'Kawasan Pantai Maju Blok B No. 18, PIK, Jakarta Utara',
                    'google_maps_link' => 'https://maps.google.com/?q=Slam+Padel+Arena',
                ],
            ];
            // Prioritaskan langsung dari database ($locations dari LocationController) jika ada data
            $displayLocations = (isset($locations) && count($locations) > 0) ? $locations : $defaultLocations;
        ?>

        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mt-12">
            <?php $__empty_1 = true; $__currentLoopData = $displayLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="bg-[#F8E2BE] border-2 border-caramel/30 rounded-3xl p-6 sm:p-7 flex flex-col justify-between hover:border-burnt/50 transition">
                    <div>
                        
                        <div class="flex items-center justify-between gap-2 mb-3">
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-cocoa text-amber">
                                <?php echo e($location->type); ?>

                            </span>
                            <span class="text-[11px] font-bold text-caramel">Partner Terverifikasi</span>
                        </div>

                        <h2 class="font-heading text-2xl text-cocoa tracking-tight mb-2">
                            <?php echo e($location->name); ?>

                        </h2>

                        <p class="text-cocoa/80 text-sm leading-relaxed mb-6">
                            <?php echo e($location->address); ?>

                        </p>
                    </div>

                    
                    <?php if($location->google_maps_link): ?>
                        <div class="pt-4 border-t border-caramel/25">
                            <a href="<?php echo e($location->google_maps_link); ?>" target="_blank" rel="noopener noreferrer" class="btn-pill-primary w-full text-center py-3 text-xs font-bold inline-flex items-center justify-center gap-1.5">
                                <span>Buka di Google Maps</span>
                                <span>&rarr;</span>
                            </a>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full bg-[#F8E2BE] border-2 border-caramel/30 rounded-3xl p-12 text-center">
                    <h3 class="font-heading text-2xl text-cocoa">Belum ada lokasi partner</h3>
                    <p class="text-cocoa/80 text-sm mt-2">Daftar lokasi gym dan padel court akan segera diperbarui.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20">
        <div class="bg-cocoa text-cream rounded-3xl lg:rounded-4xl p-8 sm:p-12 border-2 border-caramel/40 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div class="space-y-2 max-w-xl">
                <span class="text-amber text-xs font-bold uppercase tracking-widest">LET'S GROW TOGETHER</span>
                <h3 class="font-heading text-2xl sm:text-3xl text-cream tracking-tight">
                    Good Things Are Better Shared.
                </h3>
                <p class="text-cream/80 text-sm">
                    We believe good bites belong in more places. Whether you own a padel club, gym, minimarket, café, or manage a distribution business, we'd love to bring True Bite closer to your community. Let's create something good together.
                </p>
                <p class="text-cream/90 text-sm font-bold">
                    Interested in partnering with us? Let's talk!
                </p>
            </div>
            <div class="shrink-0">
                <a href="<?php echo e(config('services.truebite.whatsapp') ?: 'https://wa.me/628113777353'); ?>?text=<?php echo e(urlencode('Halo TrueBite, saya tertarik menjadi partner!')); ?>" target="_blank" rel="noopener noreferrer" class="btn-pill-primary px-8 py-4 text-sm font-bold inline-flex items-center gap-2 whitespace-nowrap">
                    <svg class="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                    </svg>
                    <span>Become Our Partner</span>
                </a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\AFLRC\Desktop\truebiteWEB\laravel\resources\views\locations.blade.php ENDPATH**/ ?>