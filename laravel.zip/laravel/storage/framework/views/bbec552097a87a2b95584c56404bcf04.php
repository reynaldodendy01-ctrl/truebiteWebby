<?php $__env->startSection('title', 'Frequently Asked Questions'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $defaultFaqs = [
        (object)[
            'question' => 'What is TrueBite?',
            'answer' => 'TrueBite is a healthier snack brand that brings together delicious taste and the goodness of protein. We create bites for people who want to enjoy their everyday snacks while making more mindful choices.'
        ],
        (object)[
            'question' => 'What makes TrueBite different?',
            'answer' => 'We believe you shouldn\'t have to choose between enjoying your food and making a more mindful choice. TrueBite combines a satisfying taste, enjoyable texture, and protein in one delicious bite.'
        ],
        (object)[
            'question' => 'Who is TrueBite made for?',
            'answer' => 'TrueBite is made for anyone who loves good food and wants a snack that fits into their active, busy lifestyle but still healthier. Whether you\'re heading to the gym, working, studying, or simply taking a break, there\'s always room for a good bite.'
        ],
        (object)[
            'question' => 'How much protein is in TrueBite?',
            'answer' => 'The protein content in 1 TrueBite product is 10g. Full details regarding protein, calories, fat, and carbohydrates can be found on the product detail page for each variant.'
        ],
        (object)[
            'question' => 'Does True Bite contain allergens?',
            'answer' => 'Our products may contain ingredients that can trigger allergies. Please check the allergen information on the packaging before consuming. For further details, contact our team.'
        ],
        (object)[
            'question' => 'How should I store True Bite?',
            'answer' => 'TrueBite products can be stored at room temperature; avoid direct sunlight and humid areas to extend shelf life.'
        ],
        (object)[
            'question' => 'Do you offer bulk or wholesale orders?',
            'answer' => 'Absolutely! We\'re open to collaborations with gyms, padel clubs, cafés, retailers, and distributors. Reach out through our partnership inquiry channel to explore the possibilities.'
        ],
        (object)[
            'question' => 'How can I become a True Bite partner?',
            'answer' => 'We\'d love to hear from you! Send us a message through WhatsApp or our contact channel with your business name, business type, and location.'
        ],
        (object)[
            'question' => 'Can I collaborate with True Bite as a content creator?',
            'answer' => 'We’re always excited to connect with creators who share our love for good food and an active lifestyle. Reach out to us through Instagram or email to introduce yourself and your ideas.'
        ],
        (object)[
            'question' => 'Is TrueBite halal?',
            'answer' => 'Yes, TrueBite products are already halal certified.'
        ],
    ];

    // Prioritaskan membaca langsung dari database tabel faqs jika ada data
    $displayFaqs = (isset($faqs) && count($faqs) > 0) ? $faqs : $defaultFaqs;
?>

    
    <section class="py-12 sm:py-16 lg:py-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-2xl mx-auto">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-caramel/25 text-cocoa text-xs font-bold tracking-wide mb-4">
                <span>Frequently Asked Questions</span>
            </div>
            <h1 class="font-heading text-4xl sm:text-6xl text-cocoa tracking-tight leading-tight">
                Curious About True Bite?
            </h1>
            <p class="text-cocoa/85 text-base sm:text-lg mt-4 leading-relaxed font-normal">
                We've got you covered. From what's inside every bite to where you can find us, here are a few things you might want to know.
            </p>
        </div>

        
        <div class="mt-12 space-y-5">
            <?php $__empty_1 = true; $__currentLoopData = $displayFaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="bg-[#F8E2BE] border-2 border-caramel/30 rounded-2xl sm:rounded-3xl p-6 sm:p-8 hover:border-burnt/50 transition">
                    <h2 class="font-heading text-xl sm:text-2xl text-cocoa tracking-tight mb-3 flex items-start gap-3">
                        <span class="text-gorilla font-extrabold text-2xl leading-none select-none">Q.</span>
                        <span><?php echo e($faq->question); ?></span>
                    </h2>
                    <div class="pl-0 sm:pl-8 text-cocoa/85 text-base leading-relaxed font-normal">
                        <p><?php echo e($faq->answer); ?></p>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="bg-[#F8E2BE] border-2 border-caramel/30 rounded-3xl p-12 text-center">
                    <h3 class="font-heading text-2xl text-cocoa">Belum ada pertanyaan</h3>
                    <p class="text-cocoa/80 text-sm mt-2">Daftar FAQ akan segera diperbarui.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    
    <section class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20">
        <div class="bg-cocoa text-cream rounded-3xl lg:rounded-4xl p-8 sm:p-12 border-2 border-caramel/40 flex flex-col md:flex-row md:items-center justify-between gap-6 text-left">
            <div class="space-y-2">
                <h3 class="font-heading text-2xl sm:text-3xl text-cream tracking-tight">
                    Still Curious?
                </h3>
                <p class="text-cream/80 text-sm max-w-lg">
                    Didn't find what you're looking for? We're just one message away.
                </p>
            </div>
            <div>
                <a href="<?php echo e(config('services.truebite.whatsapp') ?: 'https://wa.me/628113777353'); ?>?text=<?php echo e(urlencode('Halo TrueBite, saya mau tanya seputar produk!')); ?>" target="_blank" rel="noopener noreferrer" class="btn-pill-primary px-8 py-4 text-sm font-bold inline-flex items-center gap-2 whitespace-nowrap">
                    <svg class="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                    </svg>
                    <span>Contact Us</span>
                </a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\AFLRC\Desktop\truebiteWEB\laravel\resources\views\faqs.blade.php ENDPATH**/ ?>